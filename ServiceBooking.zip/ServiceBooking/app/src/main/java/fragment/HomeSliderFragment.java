package fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.squareup.picasso.Picasso;

import Config.BaseURL;
import codecanyon.servpro.R;
import model.BannerModel;

/**
 * Created on 17-06-2020.
 */
public class HomeSliderFragment extends Fragment {

    public static HomeSliderFragment newInstance(int position) {
        HomeSliderFragment f = new HomeSliderFragment();
        Bundle b = new Bundle();
        b.putInt("position", position);
        f.setArguments(b);
        return f;
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_home_slider, container, false);

        ImageView iv_img = (ImageView) rootView.findViewById(R.id.iv_home_slider);

        BannerModel bannerModel = HomeFragment.bannerModelArrayList.get(getArguments().getInt("position", 0));

        Picasso.with(getActivity())
                .load(BaseURL.IMG_BANNER_URL + bannerModel.getImage())
                .into(iv_img);

        return rootView;
    }

}
