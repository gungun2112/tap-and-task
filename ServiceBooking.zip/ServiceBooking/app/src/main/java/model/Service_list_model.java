package model;

/**
 * Created by Rajesh on 2017-09-26.
 */

public class Service_list_model {

    private String id;
    private String cat_id;
    private String service_title;
    private String service_price;
    private String service_discount;
    private String service_approxtime;
    private String service_icon;
    private String title;


    public String getId() {
        return id;
    }

    public String getCat_id() {
        return cat_id;
    }

    public String getService_title() {
        return service_title;
    }

    public String getService_price() {
        return service_price;
    }

    public String getService_discount() {
        return service_discount;
    }

    public String getService_approxtime() {
        return service_approxtime;
    }

    public String getService_icon() {
        return service_icon;
    }

    public String getTitle() {
        return title;
    }
}
