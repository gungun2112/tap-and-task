package model;

/**
 * Created by Rajesh on 2017-09-29.
 */

public class Service_detail_model {

    private String service_title;
    private String service_price;
    private String service_discount;
    private String service_approxtime;
    private String service_icon;
    private String service_qty;

    public String getService_title() {
        return service_title;
    }

    public String getService_price() {
        return service_price;
    }

    public String getService_discount() {
        return service_discount;
    }

    public String getService_approxtime() {
        return service_approxtime;
    }

    public String getService_icon() {
        return service_icon;
    }

    public String getService_qty() {
        return service_qty;
    }

}
