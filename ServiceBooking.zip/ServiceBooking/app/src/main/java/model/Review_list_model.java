package model;

/**
 * Created by Rajesh on 2017-09-26.
 */

public class Review_list_model {

    private String id;
    private String user_id;
    private String reviews;
    private String ratings;
    private String on_date;
    private String cat_id;
    private String pros_id;
    private String user_fullname;
    private String user_image;

    public String getId() {
        return id;
    }

    public String getUser_id() {
        return user_id;
    }

    public String getReviews() {
        return reviews;
    }

    public String getRatings() {
        return ratings;
    }

    public String getOn_date() {
        return on_date;
    }

    public String getCat_id() {
        return cat_id;
    }

    public String getPros_id() {
        return pros_id;
    }

    public String getUser_fullname() {
        return user_fullname;
    }

    public String getUser_image() {
        return user_image;
    }

}
