import java.util.Scanner;

public class RunnableDemo implements Runnable {
    private Thread t;
    private String threadName;
    private volatile boolean running = true; // flag to indicate whether thread should keep running

    RunnableDemo(String name) {
        threadName = name;
        System.out.println("Creating " + threadName);
    }

    public void run() {
        System.out.println("Running " + threadName);
        try {
            for (int i = 4; i > 0; i--) {
                System.out.println("Thread: " + threadName + ", " + i);
                Thread.sleep(1000); // sleep for 1 second
            }
            System.out.println("Thread " + threadName + " Exiting.");
            running = false; // set flag to stop thread
        } catch (InterruptedException e) {
            System.out.println("Thread " + threadName + " interrupted.");
        }
    }

    public void start() {
        System.out.println("Starting " + threadName);
        if (t == null) {
            t = new Thread(this, threadName);
            t.start();
        }
    }

    public boolean isRunning() {
        return running;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name of first user: ");
        String firstUser = sc.nextLine();
        System.out.print("Enter name of second user: ");
        String secondUser = sc.nextLine();

        RunnableDemo firstDemo = new RunnableDemo(firstUser);
        firstDemo.start();
        RunnableDemo secondDemo = new RunnableDemo(secondUser);
        secondDemo.start();

        while (firstDemo.isRunning() || secondDemo.isRunning()) {
            // wait for threads to complete
        }
    }
}